import React, { useEffect, useMemo, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, ArrowRight, CheckCircle2, Compass, Home, Lock, MapPinned, PartyPopper, Route, Sparkles, Ticket } from 'lucide-react'
import { getRouteBySlug, getStop, huntRoutes } from '../data/huntData'
import { areAllRoutesComplete, getFirstAvailableStop, getRouteCompletionCount, hasValidScan, isStopComplete, isStopUnlocked, markStopComplete, verifyStopAnswer, verifyVolunteerCode } from '../lib/huntGate'
import { applyRuntimeToRoute, buildRuntimeSettingsMap, awardStopCompletion, fetchHuntPublicState, getPlayerKey } from '../lib/huntTickets'

const HOME_SECTION_TARGET_KEY = 'maydayHomeSectionTarget'

function ProgressPill({ complete, total }) {
  return <div className="rounded-full border border-[#e3a7a5]/18 bg-[#e3a7a5]/10 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-[#f7f1e8]">stop {complete} of {total}</div>
}

function InfoCard({ label, value }) {
  if (!value) return null
  return (
    <div className="rounded-[1.25rem] border border-[#e3a7a5]/18 bg-black/20 p-4">
      <p className="text-[10px] uppercase tracking-[0.18em] text-[#e3a7a5]/76">{label}</p>
      <p className="mt-2 whitespace-pre-line text-sm leading-7 text-[#f7f1e8]/84">{value}</p>
    </div>
  )
}

function CelebrationOverlay({ celebration, onClose }) {
  if (!celebration) return null
  const full = celebration.kind === 'full'
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/70 px-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: full ? 80 : 28 }).map((_, index) => (
          <span
            key={index}
            className={`absolute text-2xl ${full ? 'animate-bounce' : 'animate-pulse'}`}
            style={{ left: `${(index * 11) % 96}%`, top: `${(index * 7) % 92}%`, animationDelay: `${(index % 12) * 0.08}s` }}
          >
            {full ? '🎟️' : '🎉'}
          </span>
        ))}
      </div>
      <div className="relative z-10 max-w-2xl rounded-[2rem] border border-[#e3a7a5] bg-[#264636] p-8 text-white shadow-2xl">
        <div className="flex items-center gap-3 text-[#e3a7a5]">
          <PartyPopper className="h-6 w-6" />
          <p className="text-xs font-black uppercase tracking-[0.24em]">{full ? 'full hunt complete' : 'route complete'}</p>
        </div>
        <h2 className="mt-4 text-3xl font-black uppercase tracking-tight text-[#f7f1e8]">
          {full ? 'all 50 stops complete' : `${celebration.routeTitle} complete`}
        </h2>
        <p className="mt-4 text-base leading-7 text-[#f7f1e8]/84">
          {full ? 'Confetti. Tickets raining down. The whole ridiculous thing is yours now.' : 'You finished a full route and earned the route bonus.'}
        </p>
        <p className="mt-4 text-xl font-black uppercase tracking-tight text-[#e3a7a5]">
          +{celebration.bonus} tickets
        </p>
        <div className="mt-6">
          <button type="button" onClick={onClose} className="inline-flex min-h-11 items-center rounded-full bg-[#e3a7a5] px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#264636]">
            continue
          </button>
        </div>
      </div>
    </div>
  )
}

export default function HuntStopPage() {
  const navigate = useNavigate()
  const { category, stopId } = useParams()
  const baseRoute = useMemo(() => getRouteBySlug(category), [category])
  const baseStop = useMemo(() => getStop(category, stopId), [category, stopId])
  const [publicState, setPublicState] = useState({ settings: [], summary: null })
  const [complete, setComplete] = useState(false)
  const [proofValue, setProofValue] = useState('')
  const [proofError, setProofError] = useState('')
  const [celebration, setCelebration] = useState(null)
  const playerKey = getPlayerKey()

  useEffect(() => {
    fetchHuntPublicState(playerKey).then(setPublicState).catch(() => {})
  }, [playerKey])

  useEffect(() => {
    if (category && stopId) {
      setComplete(isStopComplete(category, stopId))
      setProofValue('')
      setProofError('')
      window.scrollTo({ top: 0, left: 0, behavior: 'auto' })
    }
  }, [category, stopId])

  const settingsMap = useMemo(() => buildRuntimeSettingsMap(publicState.settings || []), [publicState])
  const route = useMemo(() => (baseRoute ? applyRuntimeToRoute(baseRoute, settingsMap) : null), [baseRoute, settingsMap])
  const stop = useMemo(() => {
    if (!route || !baseStop) return null
    const index = route.stops.findIndex((item) => item.id === baseStop.id)
    if (index === -1) return null
    return { ...route.stops[index], number: index + 1, totalStops: route.stops.length }
  }, [route, baseStop])

  function goToHomeSection(sectionId) {
    try { sessionStorage.setItem(HOME_SECTION_TARGET_KEY, sectionId) } catch {}
    navigate('/')
  }

  if (!route || !stop) {
    return <div className="min-h-screen bg-[#264636] px-4 py-8 text-white sm:px-6 lg:px-8"><div className="mx-auto max-w-4xl rounded-[2rem] border border-[#e3a7a5]/18 bg-black/20 p-6 sm:p-8"><h1 className="text-3xl font-black uppercase tracking-tight text-[#e3a7a5] sm:text-5xl">stop not found</h1></div></div>
  }

  const currentIndex = route.stops.findIndex((item) => item.id === stop.id)
  const previousStop = currentIndex > 0 ? route.stops[currentIndex - 1] : null
  const nextStop = currentIndex < route.stops.length - 1 ? route.stops[currentIndex + 1] : null
  const unlocked = isStopUnlocked(route, stop.id)
  const scannedIn = stop.validationMode === 'onsite_qr_only' ? hasValidScan(stop) : false
  const canShowNext = complete && stop.revealNextInUI !== false && nextStop

  async function onSubmit() {
    if (stop.validationMode === 'answer') {
      if (!verifyStopAnswer(stop, proofValue)) {
        setProofError('That answer does not match yet.')
        return
      }
    } else if (stop.validationMode === 'volunteer') {
      if (!verifyVolunteerCode(stop, proofValue)) {
        setProofError('That volunteer code does not match yet.')
        return
      }
    } else if (stop.validationMode === 'onsite_qr_only') {
      if (!scannedIn) {
        setProofError('This stop only progresses when you arrive from the real world QR.')
        return
      }
    }

    const wasComplete = isStopComplete(category, stop.id)
    markStopComplete(category, stop.id)
    setComplete(true)
    setProofError('')

    if (!wasComplete) {
      const runtimeRoutes = huntRoutes.map((item) => applyRuntimeToRoute(item, settingsMap))
      const currentRuntimeRoute = runtimeRoutes.find((item) => item.slug === route.slug) || route
      const routeCompleteNow = getRouteCompletionCount(currentRuntimeRoute) + 1 >= currentRuntimeRoute.stops.length
      const allCompleteNow = runtimeRoutes.every((item) => {
        if (item.slug === route.slug) {
          return getRouteCompletionCount(currentRuntimeRoute) + 1 >= currentRuntimeRoute.stops.length
        }
        return getRouteCompletionCount(item) >= item.stops.length
      })

      try {
        const result = await awardStopCompletion({
          playerKey,
          routeSlug: route.slug,
          stopId: stop.id,
          ticketValue: stop.ticketValue || 0,
          routeBonusAmount: routeCompleteNow ? 10 : 0,
          allBonusAmount: allCompleteNow ? 50 : 0,
        })

        setPublicState((current) => ({ ...current, summary: result.summary || current.summary }))

        if (result?.newFullBonus) {
          setCelebration({ kind: 'full', bonus: 50, routeTitle: route.title })
        } else if (result?.newRouteBonus) {
          setCelebration({ kind: 'route', bonus: 10, routeTitle: route.title })
        }
      } catch (error) {
        setProofError(error?.message || 'Tickets were not awarded.')
      }
    }
  }

  if (!unlocked) {
    const availableStop = getFirstAvailableStop(route)
    return (
      <div className="min-h-screen bg-[#264636] px-4 py-8 text-white sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl rounded-[2rem] border border-[#e3a7a5]/18 bg-black/20 p-6 sm:p-8">
          <div className="flex items-center gap-3 text-[#e3a7a5]"><Lock className="h-5 w-5" /><p className="text-xs uppercase tracking-[0.24em]">locked stop</p></div>
          <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-[#f7f1e8] sm:text-5xl">finish the visible stops first</h1>
          <div className="mt-6 flex flex-wrap gap-3">
            {availableStop ? <Link to={`/hunt/${route.slug}/${availableStop.id}`} className="inline-flex min-h-12 items-center rounded-full bg-[#e3a7a5] px-6 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#264636] transition hover:bg-[#efbbb9]">go to current stop</Link> : null}
            <Link to="/hunt" className="inline-flex min-h-12 items-center rounded-full border border-[#e3a7a5]/18 bg-black/20 px-6 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10">all routes</Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#264636] px-4 py-8 text-white sm:px-6 lg:px-8">
      <CelebrationOverlay celebration={celebration} onClose={() => setCelebration(null)} />
      <div className="mx-auto max-w-6xl">
        <div className="mb-6 flex flex-wrap items-center gap-3">
          <Link to="/hunt" className="inline-flex items-center rounded-full border border-[#e3a7a5]/20 bg-black/20 px-4 py-2 text-sm font-bold uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10"><ArrowLeft className="mr-2 h-4 w-4" />back to hunt</Link>
          <Link to="/" className="inline-flex items-center rounded-full border border-[#e3a7a5]/20 bg-black/20 px-4 py-2 text-sm font-bold uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10"><Home className="mr-2 h-4 w-4" />home</Link>
        </div>

        <section className="rounded-[2rem] border border-[#e3a7a5]/18 bg-black/20 p-6 sm:p-8">
          <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
            <div>
              <p className="text-xs uppercase tracking-[0.24em] text-[#e3a7a5]/80">{route.title}</p>
              <h1 className="mt-3 text-3xl font-black uppercase tracking-tight text-[#e3a7a5] sm:text-5xl">{stop.title}</h1>
              <p className="mt-4 max-w-3xl whitespace-pre-line text-base leading-8 text-[#f7f1e8]/84">{stop.clue}</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <ProgressPill complete={stop.number} total={stop.totalStops} />
              <div className={`rounded-full border px-4 py-2 text-xs font-black uppercase tracking-[0.14em] ${complete ? 'border-[#e3a7a5] bg-[#e3a7a5] text-[#264636]' : 'border-[#e3a7a5]/18 bg-black/20 text-[#f7f1e8]'}`}>{complete ? 'completed' : 'in progress'}</div>
              <div className="rounded-full border border-[#e3a7a5]/18 bg-black/20 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-[#f7f1e8]">{stop.validationMode || 'manual'}</div>
              <div className="rounded-full border border-[#e3a7a5]/18 bg-black/20 px-4 py-2 text-xs font-black uppercase tracking-[0.14em] text-[#f7f1e8]">{stop.ticketValue || 0} tickets</div>
            </div>
          </div>

          <div className="mt-8 grid gap-4 lg:grid-cols-[1.15fr_.85fr]">
            <div className="space-y-4">
              <div className="rounded-[1.5rem] border border-[#e3a7a5]/18 bg-[#e3a7a5]/8 p-5 sm:p-6">
                <div className="flex items-center gap-3 text-[#e3a7a5]"><Sparkles className="h-5 w-5" /><h2 className="text-lg font-black uppercase tracking-tight">what to do</h2></div>
                <p className="mt-4 whitespace-pre-line text-base leading-8 text-[#f7f1e8]/86">{stop.answerPrompt}</p>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <InfoCard label="hint" value={stop.hint} />
                <InfoCard label="difficulty" value={String(stop.difficulty || 0)} />
              </div>

              {stop.validationMode === 'answer' ? (
                <div className="rounded-[1.5rem] border border-[#e3a7a5]/18 bg-black/20 p-5 sm:p-6">
                  <div className="flex items-center gap-3 text-[#e3a7a5]"><Sparkles className="h-5 w-5" /><h2 className="text-lg font-black uppercase tracking-tight">submit your answer</h2></div>
                  <label className="mt-5 block">
                    <span className="mb-2 block text-[10px] uppercase tracking-[0.18em] text-[#e3a7a5]/76">answer</span>
                    <input value={proofValue} onChange={(e) => setProofValue(e.target.value)} className="w-full rounded-2xl border border-[#e3a7a5]/18 bg-black/20 px-4 py-3 text-sm text-[#f7f1e8] outline-none transition focus:border-[#e3a7a5]/35" placeholder="type your answer" />
                  </label>
                  {proofError ? <p className="mt-3 text-sm text-[#ffb0b0]">{proofError}</p> : null}
                  <div className="mt-5"><button type="button" onClick={onSubmit} className="inline-flex min-h-12 items-center rounded-full bg-[#e3a7a5] px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#264636] transition hover:bg-[#efbbb9]">submit answer</button></div>
                </div>
              ) : stop.validationMode === 'volunteer' ? (
                <div className="rounded-[1.5rem] border border-[#e3a7a5]/18 bg-black/20 p-5 sm:p-6">
                  <div className="flex items-center gap-3 text-[#e3a7a5]"><Ticket className="h-5 w-5" /><h2 className="text-lg font-black uppercase tracking-tight">volunteer checkpoint</h2></div>
                  <p className="mt-4 text-sm leading-7 text-[#f7f1e8]/78">A volunteer needs to enter the completion code on your phone for this stop.</p>
                  <label className="mt-5 block">
                    <span className="mb-2 block text-[10px] uppercase tracking-[0.18em] text-[#e3a7a5]/76">volunteer code</span>
                    <input value={proofValue} onChange={(e) => setProofValue(e.target.value)} className="w-full rounded-2xl border border-[#e3a7a5]/18 bg-black/20 px-4 py-3 text-sm text-[#f7f1e8] outline-none transition focus:border-[#e3a7a5]/35" placeholder="enter volunteer code" />
                  </label>
                  {proofError ? <p className="mt-3 text-sm text-[#ffb0b0]">{proofError}</p> : null}
                  <div className="mt-5"><button type="button" onClick={onSubmit} className="inline-flex min-h-12 items-center rounded-full bg-[#e3a7a5] px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#264636] transition hover:bg-[#efbbb9]">confirm checkpoint</button></div>
                </div>
              ) : (
                <div className="rounded-[1.5rem] border border-[#e3a7a5]/18 bg-black/20 p-5 sm:p-6">
                  <div className="flex items-center gap-3 text-[#e3a7a5]"><Compass className="h-5 w-5" /><h2 className="text-lg font-black uppercase tracking-tight">physical clue only</h2></div>
                  <p className="mt-4 text-sm leading-7 text-[#f7f1e8]/78">
                    {scannedIn ? 'You reached this stop from the real world clue. Record the arrival to lock in your tickets.' : 'This stop only progresses when you arrive from the real world QR. The site will not reveal the next page here.'}
                  </p>
                  {proofError ? <p className="mt-3 text-sm text-[#ffb0b0]">{proofError}</p> : null}
                  {scannedIn ? <div className="mt-5"><button type="button" onClick={onSubmit} className="inline-flex min-h-12 items-center rounded-full bg-[#e3a7a5] px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#264636] transition hover:bg-[#efbbb9]">record arrival</button></div> : null}
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="rounded-[1.5rem] border border-[#e3a7a5]/18 bg-black/20 p-5 sm:p-6">
                <div className="flex items-center gap-3 text-[#e3a7a5]"><Compass className="h-5 w-5" /><h2 className="text-lg font-black uppercase tracking-tight">route context</h2></div>
                <p className="mt-4 text-sm leading-7 text-[#f7f1e8]/78">{route.intro}</p>
              </div>

              <div className="rounded-[1.5rem] border border-[#e3a7a5]/18 bg-black/20 p-5 sm:p-6">
                <div className="flex items-center gap-3 text-[#e3a7a5]"><Route className="h-5 w-5" /><h2 className="text-lg font-black uppercase tracking-tight">next move</h2></div>
                <p className="mt-4 text-sm leading-7 text-[#f7f1e8]/78">
                  {stop.revealNextInUI === false
                    ? 'The next clue for this stop stays in the physical hunt. Find it in the space or get it from the volunteer.'
                    : 'Complete the current stop, then move forward.'}
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  {canShowNext ? <Link to={`/hunt/${category}/${nextStop.id}`} className="inline-flex min-h-12 items-center rounded-full border border-[#e3a7a5]/18 bg-black/20 px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10">next stop<ArrowRight className="ml-2 h-4 w-4" /></Link> : null}
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            {previousStop ? <Link to={`/hunt/${category}/${previousStop.id}`} className="inline-flex min-h-11 items-center rounded-full border border-[#e3a7a5]/18 bg-black/20 px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10"><ArrowLeft className="mr-2 h-4 w-4" />previous stop</Link> : null}
            <button type="button" onClick={() => goToHomeSection('map')} className="inline-flex min-h-11 items-center rounded-full border border-[#e3a7a5]/18 bg-black/20 px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10"><MapPinned className="mr-2 h-4 w-4" />venue map</button>
            <Link to="/hunt" className="inline-flex min-h-11 items-center rounded-full border border-[#e3a7a5]/18 bg-black/20 px-5 py-3 text-sm font-black uppercase tracking-[0.14em] text-[#f7f1e8] transition hover:bg-[#e3a7a5]/10">all routes</Link>
          </div>
        </section>
      </div>
    </div>
  )
}
