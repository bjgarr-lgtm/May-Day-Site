import React from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import ScrollToTop from './components/ScrollToTop'
import MayDayWelcomeCenter from './pages/MayDayWelcomeCenter'
import HuntHome from './pages/HuntHome'
import HuntStopPage from './pages/HuntStopPage'
import LaborHistoryPage from './pages/LaborHistoryPage'
import VendorApplicationPage from './pages/VendorApplicationPage'
import PerformerApplicationPage from './pages/PerformerApplicationPage'
import VolunteerApplicationPage from './pages/VolunteerApplicationPage'
import PosterArtContestPage from './pages/PosterArtContestPage'
import ApplicationsDashboardPage from './pages/ApplicationsDashboardPage'
import OpsApp from './admin/ops'

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<MayDayWelcomeCenter />} />
        <Route path="/hunt" element={<HuntHome />} />
        <Route path="/hunt/:category/:stopId" element={<HuntStopPage />} />
        <Route path="/labor-history" element={<LaborHistoryPage />} />
        <Route path="/vendor-application" element={<VendorApplicationPage />} />
        <Route path="/performer-application" element={<PerformerApplicationPage />} />
        <Route path="/volunteer-application" element={<VolunteerApplicationPage />} />
        <Route path="/poster-art-contest" element={<PosterArtContestPage />} />
        <Route path="/admin" element={<ApplicationsDashboardPage />} />
        <Route path="/applications" element={<Navigate to="/admin" replace />} />
        <Route path="/admin/ops/*" element={<OpsApp />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  )
}
